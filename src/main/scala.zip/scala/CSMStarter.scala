package com.ctrip.fin.csm

import com.ctrip.fin.csm.utils.{Utils, _}
import com.ctrip.fin.csm.model._
import org.apache.spark.sql.{DataFrame, Row, SQLContext}
import org.apache.spark.{SparkConf, SparkContext}


/**
  * Created by zyong on 2016/10/13.
  */
object CSMStarter {

  var sc: SparkContext = null
  var sqlContext: SQLContext = null
  val baseOutputPath = "/user/bifinread/csm/"

  /**
    * 训练模型
    * 保存模型与Scaler对象
    *
    * @param moduleName
    * @return
    */
  def train(moduleName: String, dataPath: String) = {

    val startTime = System.currentTimeMillis()
    val data = Utils.readJson(dataPath,sqlContext)
    moduleName match {
      case "consume"     => new ConsumeModel().dataTraining(data)
      case "finance"     => new FinanceModel().dataTraining(data)
      case "interaction" => new InteractionModel().dataTraining(data)
      case "people"      => new PeopleModel().dataTraining(data)
      case "relation"    => new RelationModel().dataTraining(data)
      case _ =>
    }
    val endTime = System.currentTimeMillis()
    println("TRAIN TIME COST： "+(endTime - startTime)+"ms")
  }

  /**
    * 预测结果
    *
    * @param moduleName
    * @param dataPath
    * @return
    */
  def predict(moduleName: String, dataPath: String) = {

    val startTime = System.currentTimeMillis()

    val data = Utils.readCsv(dataPath,sqlContext)
    val predictDF: DataFrame = moduleName match {
      case "consume"     => new ConsumeModel().dataPredict(data)
      case "finance"     => new FinanceModel().dataPredict(data)
      case "interaction" => new InteractionModel().dataPredict(data)
      case "people"      => new PeopleModel().dataPredict(data)
      case "relation"    => new RelationModel().dataPredict(data)
    }

    val endTime = System.currentTimeMillis()
    println("PREDICT TIME COST： "+(endTime - startTime)+"ms")
    predictDF.show()
  }

  /**
    * Combine all of the score
    */
  def combineResult() = {
    val consumeDF     = new ConsumeModel().readPredictedData(sqlContext)
    val financeDF     = new FinanceModel().readPredictedData(sqlContext)
    val interactionDF = new InteractionModel().readPredictedData(sqlContext)
    val peopleDF      = new PeopleModel().readPredictedData(sqlContext)
    val relationDF    = new RelationModel().readPredictedData(sqlContext)
    val combinedDF    = Utils.concatDataFrame(consumeDF, financeDF, interactionDF, peopleDF, relationDF)
    val combineDF2    = consumeDF.join(peopleDF,"uid_uid")

    val score = combinedDF.withColumn("ScoreAll",
        combinedDF("ScorePeople") * 0.3 +
        combinedDF("ScoreConsume") * 0.25 +
        combinedDF("ScoreFinance") * 0.2 +
        combinedDF("ScoreInteraction") * 0.15 +
        combinedDF("ScoreRelation") * 0.1)

    score.show(50)
    println(score.count())
    combineDF2.show(50)
    println(combineDF2.count())
//    score.write.format("com.databricks.spark.csv")
//      .option("header","true")
//      .save("/home/bifinread/myscore.csv")
  }


    //-----------------------MAIN FUNCTION----------------------------//
  def main(args: Array[String]): Unit = {

    val appName    = args(0)
    val appType    = args(1) // train,predict,combine
    val moduleName = args(2) // sub-model name
    val dataPath   = args(3)


    val conf = new SparkConf().setAppName(appName).setMaster("local")
    sc = new SparkContext(conf)
    sqlContext = new SQLContext(sc)

    appType match {
      case "train"   => train(moduleName, dataPath)
      case "predict" => predict(moduleName, dataPath)
      case "combine" => combineResult()
    }
  }
  //---------------------------------------------------------------//
}
